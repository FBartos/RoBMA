library(testthat)
library(vdiffr)
library(RoBMA)

test_check("RoBMA")
